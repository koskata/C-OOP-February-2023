﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            FamilyCar family = new(150, 30);

            family.Drive(20);
        }
    }
}
