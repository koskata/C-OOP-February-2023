﻿using _04.BorderControl.Core;
using _04.BorderControl.Core.Interfaces;

using _05.BirthdayCelebrations.Models;

namespace _05.BirthdayCelebrations
{
    public class Program
    {
        static void Main(string[] args)
        {
            IEngine engine = new Engine();

            engine.Run();


        }
    }
}